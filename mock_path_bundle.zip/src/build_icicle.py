
import pandas as pd
from collections import defaultdict

EVENTS_FILE = "data/events.csv"
MAX_DEPTH   = 3  # default

_events = pd.read_csv(EVENTS_FILE, parse_dates=["occurred_at"])\
          .sort_values(["visitor_id","session_id","occurred_at"])

def build_icicle(anchor_id: str, depth:int=MAX_DEPTH):
    """Return dict in ObservableHQ Zoomable-Icicle format."""
    anchor_rows = _events[_events.item_id == anchor_id]
    if anchor_rows.empty:
        raise ValueError(f"Anchor id {anchor_id} not found.")

    anchor_name = anchor_rows.iloc[0].item_name

    def take_path(df):
        out=[]; flag=False
        for _,r in df.iterrows():
            if flag and len(out)<depth:
                out.append(f"{r.event_type}: {r.item_name}")
            if r.item_id==anchor_id:
                flag=True
        return out

    paths = (_events.groupby(['visitor_id','session_id'])
                    .apply(take_path).tolist())

    tree={'__cnt':0,'__ch':{}}
    def add(seg,node):
        if not seg: return
        h,*t = seg
        c=node['__ch'].setdefault(h,{'__cnt':0,'__ch':{}})
        c['__cnt'] += 1
        add(t,c)

    for p in paths: add(p,tree)

    def to_json(name,node):
        kids=[to_json(k,v) for k,v in node['__ch'].items()]
        return {'name':name, **({'children':kids} if kids else {'value':node['__cnt']})}
    return to_json(anchor_name, tree)
